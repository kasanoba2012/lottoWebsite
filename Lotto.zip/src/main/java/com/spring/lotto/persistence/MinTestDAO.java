package com.spring.lotto.persistence;

import java.util.List;

import com.spring.lotto.domain.MinTestVO;

public interface MinTestDAO {
   
   public abstract List<MinTestVO> select();
   public abstract List<MinTestVO> choice_select(int hit_select_number_choice);
   public abstract List<Integer> number_choice_select(int hit_select_number_choice);
   public abstract List<MinTestVO> low_choice_select(int low_hit_select_number_choice);
   public abstract String chekc_test(String test_number);
   

}