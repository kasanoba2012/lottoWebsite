package com.spring.lotto.domain;

public class WinVO {
	
	private int lotto_number;
	private int choice_number;
	
	public WinVO() {}

	public WinVO(int lotto_number, int choice_number) {
		super();
		this.lotto_number = lotto_number;
		this.choice_number = choice_number;
	}

	public int getLotto_number() {
		return lotto_number;
	}

	public void setLotto_number(int lotto_number) {
		this.lotto_number = lotto_number;
	}

	public int getChoice_number() {
		return choice_number;
	}

	public void setChoice_number(int choice_number) {
		this.choice_number = choice_number;
	}
	

}
